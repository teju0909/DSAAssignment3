package in.ineuron;

import java.util.ArrayList;
import java.util.List;

public class Seven {
	    public List<String> findMissingRanges(int[] nums, int lower, int upper) {
	        List<String> res = new ArrayList<String>();
	        int next = lower;
	        for (int i = 0; i < nums.length; i++) {
	            if(lower == Integer.MAX_VALUE) 
	            	return res;
	            if (nums[i] < next) {
	                continue;
	            }
	            if (nums[i] == next) {
	                next++;
	                continue;
	            }
	            res.add(getRange(next, nums[i] - 1));
	            if(nums[i] == Integer.MAX_VALUE) return res;
	            next = nums[i] + 1;
	        }
	        
	        if (next <= upper) {
	            res.add(getRange(next, upper));
	        }
	        return res;
	    }
	    
	    public String getRange(int n1, int n2) {
	        return n1 == n2 ? String.valueOf(n1) : String.format("%d - %d" , n1, n2);
	    }
	public static void main(String[] args) {
		int nums[] = {0,1,3,50,75}; 
		int lower = 0;
		int upper = 99;
		Seven seven = new Seven();
		List<String> findMissingRanges = seven.findMissingRanges(nums, lower, upper);
		System.out.println("["+findMissingRanges+"]");

	}

}
